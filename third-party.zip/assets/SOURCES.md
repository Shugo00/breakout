# 素材と出典

NotoSansCJKjp-Regular.otf は共通の固定参考 blackjack-0.1.0-rc2/assets から同梱した．ライセンス・著作権表示は同梱の [OFL-NotoSansCJK.txt](OFL-NotoSansCJK.txt) を参照する．ブロック・バー・球はプログラムで描く．効果音は本作用に [tools/render_effects.py](../tools/render_effects.py) で合成し，同じ波形のWAVを両版で使う．プレイ中の [rally.wav](rally.wav) はオリジナル曲．[生成スクリプト](../tools/render_music.py) に譜面と音色を収録し，Pythonの標準ライブラリで再生成できる．

Windowsの保存に用いる src/atomicfile.py は共通部品 v1.0.0 の原本を複製した．SHA-256 は 2c5b942626f509b6e8b632a0934d6f97206954c5949095513ddf8a6b333088d5．
